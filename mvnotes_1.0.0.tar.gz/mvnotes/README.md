# mvnotes — Multivariate Analysis Study Notes

An R package that puts your complete Multivariate Analysis notes
directly inside RStudio — accessible like any help page, with no
internet, no login, and no cloud needed.

---

## Installation (One-Time Setup)

### Step 1 — Get the file onto the college computer
Copy `mvnotes_1.0.0.tar.gz` to the computer via:
- USB drive
- Email attachment (download it locally)
- Any method — you just need the .tar.gz file somewhere on disk

### Step 2 — Install in RStudio
Open RStudio and run ONE of these:

```r
# Option A — point to wherever you saved the file
install.packages("C:/Users/YourName/Desktop/mvnotes_1.0.0.tar.gz",
                 repos = NULL, type = "source")

# Option B — from USB drive (Windows)
install.packages("E:/mvnotes_1.0.0.tar.gz",
                 repos = NULL, type = "source")

# Option C — from USB drive (Mac/Linux)
install.packages("/Volumes/USB/mvnotes_1.0.0.tar.gz",
                 repos = NULL, type = "source")
```

### Step 3 — Done. Now use it any time:

```r
library(mvnotes)    # load once per session
mvnotes()           # open the index
```

---

## All Commands

| Command | Opens |
|---|---|
| `mvnotes()` | Master index & navigation guide |
| `mv_regression()` | Multivariate data, notation, regression theory, 7 results |
| `mv_correlation()` | Multiple correlation coefficient R, R² |
| `mv_partial_corr()` | Partial correlation, spurious correlation |
| `mv_distributions()` | Joint pmf/pdf, marginal, conditional, mean vector, Σ |
| `mv_normal()` | MVN density, BVN, linear combinations, partitioning |
| `mv_multinomial()` | Multinomial pmf, all 7 properties, formulas |
| `mv_wishart()` | MLE, Wishart distribution, Hotelling T² |
| `mv_visualization()` | Mosaic, SPLOM, Q-Q, Spider, DD, Parallel, Trellis |
| `mv_problems()` | All worked problem sets with complete solutions |
| `mv_formulas()` | One-page formula quick reference |

Notes open in the **RStudio Viewer pane** (or browser if outside RStudio).

---

## Sharing / Updating

- Carry `mvnotes_1.0.0.tar.gz` on a USB — reinstall on any computer
- To update: edit the source, rebuild with `R CMD build mvnotes/`
- The package installs permanently until you uninstall it:
  `remove.packages("mvnotes")`
