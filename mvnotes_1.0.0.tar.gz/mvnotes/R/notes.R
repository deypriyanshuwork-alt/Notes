# ============================================================
#  mvnotes — Multivariate Analysis Study Notes Package
#  All functions open notes in the RStudio Viewer / browser
# ============================================================

# ---- internal helper: render HTML in viewer ----------------
.show_notes <- function(html_content, title = "Multivariate Notes") {
  tmp <- tempfile(fileext = ".html")
  writeLines(html_content, tmp)
  if (requireNamespace("rstudioapi", quietly = TRUE) &&
      rstudioapi::isAvailable()) {
    rstudioapi::viewer(tmp)
  } else {
    utils::browseURL(paste0("file://", tmp))
  }
  invisible(tmp)
}

# ---- CSS shared across all pages ---------------------------
.css <- function() {
'<style>
@import url("https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=Source+Serif+4:wght@300;400;600&family=JetBrains+Mono:wght@400;600&display=swap");
:root{--ink:#1a1410;--paper:#fdf8f0;--cream:#f5ede0;--accent:#8b2635;
  --gold:#c9973a;--teal:#2a6b6b;--blue:#2b4a8b;--purple:#5a2d82;
  --green:#1e5e3a;--border:#d4c4a8;}
*{box-sizing:border-box;margin:0;padding:0;}
body{background:var(--paper);color:var(--ink);
  font-family:"Source Serif 4",Georgia,serif;font-size:15px;line-height:1.8;
  max-width:900px;margin:0 auto;padding:1.5rem;}
h1{font-family:"Playfair Display",serif;font-size:2rem;font-weight:900;
  color:var(--accent);border-bottom:3px solid var(--gold);padding-bottom:.5rem;margin-bottom:1.2rem;}
h2{font-family:"Playfair Display",serif;font-size:1.4rem;color:var(--blue);
  margin:1.5rem 0 .5rem;border-left:4px solid var(--gold);padding-left:.8rem;}
h3{font-family:"Playfair Display",serif;font-size:1.1rem;color:var(--teal);margin:1rem 0 .3rem;}
.notes{background:#fffbf0;border:1px solid #e0d4b8;border-top:none;padding:1rem 1.2rem;border-radius:0 0 6px 6px;}
.notes-hdr{background:var(--ink);color:var(--gold);padding:.4rem 1rem;
  font-family:"Playfair Display",serif;font-size:.72rem;font-weight:700;
  letter-spacing:2px;text-transform:uppercase;border-radius:6px 6px 0 0;}
.explain{background:#f0faf5;border:1px solid #b8ddd0;border-top:none;padding:1rem 1.2rem;border-radius:0 0 6px 6px;}
.explain-hdr{background:var(--teal);color:#fff;padding:.4rem 1rem;
  font-family:"Playfair Display",serif;font-size:.72rem;font-weight:700;
  letter-spacing:2px;text-transform:uppercase;border-radius:6px 6px 0 0;}
.formula{background:#f0f4ff;border:1px solid #c0ccee;border-top:none;padding:1rem 1.2rem;border-radius:0 0 6px 6px;}
.formula-hdr{background:var(--blue);color:#fff;padding:.4rem 1rem;
  font-family:"Playfair Display",serif;font-size:.72rem;font-weight:700;
  letter-spacing:2px;text-transform:uppercase;border-radius:6px 6px 0 0;}
.example{background:#fffbf2;border:1px solid #e8d8a0;border-top:none;padding:1rem 1.2rem;border-radius:0 0 6px 6px;}
.example-hdr{background:var(--gold);color:var(--ink);padding:.4rem 1rem;
  font-family:"Playfair Display",serif;font-size:.72rem;font-weight:700;
  letter-spacing:2px;text-transform:uppercase;border-radius:6px 6px 0 0;}
.solution{background:#f2fff7;border:1px solid #a8e0c0;border-top:none;padding:1rem 1.2rem;border-radius:0 0 6px 6px;}
.solution-hdr{background:var(--green);color:#fff;padding:.4rem 1rem;
  font-family:"Playfair Display",serif;font-size:.72rem;font-weight:700;
  letter-spacing:2px;text-transform:uppercase;border-radius:6px 6px 0 0;}
.block{margin-bottom:1.2rem;}
pre,code{font-family:"JetBrains Mono",monospace;font-size:.85rem;
  background:rgba(43,74,139,.07);border-left:3px solid var(--blue);
  padding:.6rem 1rem;border-radius:0 4px 4px 0;white-space:pre-wrap;
  overflow-x:auto;display:block;margin:.5rem 0;}
.callout{background:linear-gradient(135deg,#fff9e6,#fffdf5);
  border:1px solid var(--gold);border-left:4px solid var(--gold);
  border-radius:4px;padding:.8rem 1rem;margin:.8rem 0;font-size:.93rem;}
.callout strong{color:var(--accent);}
table{width:100%;border-collapse:collapse;font-size:.88rem;margin:.8rem 0;}
th{background:var(--ink);color:var(--gold);padding:.45rem .8rem;text-align:left;}
td{padding:.4rem .8rem;border-bottom:1px solid var(--border);}
tr:nth-child(even) td{background:var(--cream);}
ul,ol{padding-left:1.4rem;}
li{margin-bottom:.3rem;}
hr{border:none;border-top:2px dashed var(--border);margin:2rem 0;}
.nav-bar{background:var(--ink);padding:.7rem 1rem;border-radius:6px;
  margin-bottom:1.5rem;display:flex;flex-wrap:wrap;gap:.5rem;}
.nav-bar a{color:var(--gold);text-decoration:none;font-size:.8rem;
  font-family:"JetBrains Mono",monospace;padding:.25rem .6rem;
  border:1px solid #444;border-radius:3px;transition:background .2s;}
.nav-bar a:hover{background:#333;}
.tag{display:inline-block;background:var(--accent);color:#fff;font-size:.68rem;
  font-family:"JetBrains Mono",monospace;padding:.1em .5em;border-radius:3px;margin-left:.3rem;}
footer{text-align:center;padding:1.5rem;color:#888;font-size:.82rem;
  border-top:1px solid var(--border);margin-top:2rem;}
</style>'
}

.nav <- function(current = "") {
  links <- c(
    "mvnotes()"         = "mvnotes()",
    "Descriptive"       = "mv_regression()",
    "Regression"        = "mv_regression()",
    "Correlation"       = "mv_correlation()",
    "Partial Corr"      = "mv_partial_corr()",
    "Distributions"     = "mv_distributions()",
    "MVN"               = "mv_normal()",
    "Multinomial"       = "mv_multinomial()",
    "Wishart/T2"        = "mv_wishart()",
    "Visualization"     = "mv_visualization()",
    "Problems"          = "mv_problems()",
    "Formulas"          = "mv_formulas()"
  )
  items <- paste0('<a href="#" onclick="', names(links), ';return false;">', names(links), '</a>')
  paste0('<div class="nav-bar">', paste(items, collapse=""), '</div>')
}


# ============================================================
#  mvnotes() — Master index
# ============================================================

#' Open the Multivariate Analysis Study Notes
#'
#' Opens the full notes index in the RStudio Viewer pane or your browser.
#' Use the other functions to jump to specific topics, or navigate from
#' the index.
#'
#' @return Opens notes in viewer invisibly. No return value.
#' @examples
#' mvnotes()           # master index
#' mv_regression()     # multiple regression theory
#' mv_correlation()    # multiple correlation coefficient
#' mv_partial_corr()   # partial correlation & spurious correlation
#' mv_distributions()  # multivariate probability distributions
#' mv_normal()         # multivariate normal distribution
#' mv_multinomial()    # multinomial distribution & properties
#' mv_wishart()        # wishart distribution & hotelling T2
#' mv_visualization()  # visualization techniques
#' mv_problems()       # worked problem sets
#' mv_formulas()       # quick reference formula sheet
#' @export
mvnotes <- function() {
  html <- paste0(
    '<!DOCTYPE html><html><head><meta charset="UTF-8">',
    '<title>Multivariate Analysis Notes</title>', .css(), '</head><body>',
    '<h1>Multivariate Analysis — Complete Study Notes</h1>',
    '<p style="color:#666;margin-bottom:1.5rem;">Run any function below in your R console to open that section.</p>',

    '<div class="block"><div class="notes-hdr">📚 HOW TO USE THESE NOTES</div>',
    '<div class="notes">',
    '<p>Type any of the following in your <strong>RStudio console</strong>:</p>',
    '<pre>library(mvnotes)   # load once per session

mvnotes()           # this index
mv_regression()     # multiple regression equation (full theory)
mv_correlation()    # multiple correlation coefficient
mv_partial_corr()   # partial correlation & spurious correlation
mv_distributions()  # multivariate probability distributions
mv_normal()         # multivariate normal distribution (MVN)
mv_multinomial()    # multinomial distribution & all 7 properties
mv_wishart()        # wishart distribution & hotelling T2
mv_visualization()  # mosaic, SPLOM, QQ, spider, DD, parallel, trellis
mv_problems()       # worked problem sets (with full solutions)
mv_formulas()       # one-page formula quick reference</pre>',
    '</div></div>',

    '<div class="block"><div class="notes-hdr">📋 CONTENTS AT A GLANCE</div>',
    '<div class="notes">',
    '<table>',
    '<tr><th>Function</th><th>Topics Covered</th></tr>',
    '<tr><td><code>mv_regression()</code></td><td>Multivariate data notation, types of problems, sample statistics, correlation matrix, regression formula, 7 important results</td></tr>',
    '<tr><td><code>mv_correlation()</code></td><td>Multiple correlation coefficient R, definition, formula, remarks, R² interpretation</td></tr>',
    '<tr><td><code>mv_partial_corr()</code></td><td>Partial correlation definition, construction via residuals, formula, spurious correlation, numerical examples</td></tr>',
    '<tr><td><code>mv_distributions()</code></td><td>Joint pmf/pdf, marginal distributions, conditional distributions, mean vector, dispersion matrix, correlation matrix</td></tr>',
    '<tr><td><code>mv_normal()</code></td><td>MVN density, BVN, uncorrelated ⟺ independent, linear combinations, partitioning, conditional distributions</td></tr>',
    '<tr><td><code>mv_multinomial()</code></td><td>Multinomial pmf, all 7 properties, multiple & partial correlation formulas, worked examples</td></tr>',
    '<tr><td><code>mv_wishart()</code></td><td>Sampling from MVN, MLE, SSCP matrix, Wishart distribution, Hotelling T², T²–F relationship</td></tr>',
    '<tr><td><code>mv_visualization()</code></td><td>Mosaic plots, SPLOM, Q-Q plots, spider charts, DD plots, parallel coordinates, trellis displays</td></tr>',
    '<tr><td><code>mv_problems()</code></td><td>Problem Set 1 (chicken data), Problem Set 2 (multinomial: balls, die, words) — with complete solutions</td></tr>',
    '<tr><td><code>mv_formulas()</code></td><td>Every formula on one page for quick exam reference</td></tr>',
    '</table>',
    '</div></div>',

    '<footer>mvnotes v1.0.0 &nbsp;·&nbsp; Multivariate Analysis Study Notes</footer>',
    '</body></html>'
  )
  .show_notes(html, "Multivariate Notes — Index")
}


# ============================================================
#  mv_regression() — Descriptive stats + regression theory
# ============================================================

#' Multivariate Descriptive Statistics & Multiple Regression
#'
#' Opens notes on multivariate data notation, types of problems,
#' sample statistics, the correlation matrix, regression equation,
#' partial regression coefficients, and the 7 important results.
#'
#' @export
mv_regression <- function() {
  html <- paste0(
'<!DOCTYPE html><html><head><meta charset="UTF-8">
<title>Multiple Regression — mvnotes</title>', .css(), '</head><body>
<h1>Multivariate Descriptive Statistics & Multiple Regression</h1>

<h2>1. What is Multivariate Data?</h2>
<div class="block"><div class="notes-hdr">📓 FROM NOTES</div><div class="notes">
<p>Data collected on <strong>p variables</strong> from each of <strong>n individuals</strong>.</p>
<p><strong>Notation:</strong> x<sub>iα</sub> = value of variable x<sub>i</sub> for the α-th individual &nbsp;(i=1,…,p; α=1,…,n)</p>
<p><strong>Types of problems:</strong></p>
<ul>
<li><strong>Multiple Regression:</strong> One variable x<sub>1</sub> of principal interest — express x<sub>1</sub> as a function of x<sub>2</sub>,…,x<sub>p</sub> for prediction.</li>
<li><strong>Multiple Correlation:</strong> How much does x<sub>1</sub> depend on x<sub>2</sub>,…,x<sub>p</sub> together?</li>
<li><strong>Partial Correlation:</strong> Two variables x<sub>1</sub>, x<sub>2</sub> of interest — find their correlation after eliminating effects of x<sub>3</sub>,…,x<sub>p</sub> from both.</li>
</ul>
<p><em>Note: We consider only <strong>linear</strong> relationships.</em></p>
</div></div>

<h2>2. Sample Statistics</h2>
<div class="block"><div class="formula-hdr">🔢 FORMULAS</div><div class="formula">
<pre>x̄ᵢ = (1/n) Σα xᵢα                        Mean of xᵢ

sᵢ² = (1/n) Σα (xᵢα − x̄ᵢ)²              Variance of xᵢ

sᵢⱼ = (1/n) Σα (xᵢα−x̄ᵢ)(xⱼα−x̄ⱼ)       Cov(xᵢ, xⱼ)

rᵢⱼ = sᵢⱼ / (sᵢ · sⱼ)                    Corr(xᵢ, xⱼ),   rᵢᵢ = 1

Correlation Matrix R:
     ⎡ 1    r₁₂  r₁₃ … r₁ₚ ⎤
R =  ⎢ r₂₁  1    r₂₃ … r₂ₚ ⎥     Rᵢⱼ = cofactor of rᵢⱼ in R
     ⎣ rₚ₁  rₚ₂  rₚ₃ …  1  ⎦</pre>
</div></div>

<h2>3. Multiple Regression Equation</h2>
<div class="block"><div class="notes-hdr">📓 FROM NOTES</div><div class="notes">
<p>The multiple linear regression equation of x<sub>1</sub> on x<sub>2</sub>, x<sub>3</sub>, …, x<sub>p</sub>:</p>
</div></div>
<div class="block"><div class="formula-hdr">🔢 FORMULAS</div><div class="formula">
<pre>X₁.₂₃…ₚ = b₀ + b₂x₂ + b₃x₃ + … + bₚxₚ

where X₁.₂₃…ₚ = predicted/regressed value of x₁

bⱼ = − (R₁ⱼ / R₁₁) · (s₁/sⱼ),     j = 2, 3, …, p    ← NOTE the minus sign!

b₀ = x̄₁ − b₂x̄₂ − b₃x̄₃ − … − bₚx̄ₚ

Full form:
X₁.₂₃…ₚ = x̄₁ − (R₁₂/R₁₁)(s₁/s₂)(x₂−x̄₂)
               − (R₁₃/R₁₁)(s₁/s₃)(x₃−x̄₃) − … − (R₁ₚ/R₁₁)(s₁/sₚ)(xₚ−x̄ₚ)</pre>
</div></div>
<div class="block"><div class="explain-hdr">💡 SIMPLE EXPLANATION</div><div class="explain">
<p><strong>bⱼ (partial regression coefficient):</strong> The amount by which the predicted x₁ increases for a 1-unit increase in xⱼ, with all other variables held constant.</p>
<p><strong>Step-by-step computation:</strong> (1) Build R, (2) Compute cofactors R₁₁, R₁₂,…,R₁ₚ, (3) Apply bⱼ = −(R₁ⱼ/R₁₁)·(s₁/sⱼ), (4) Compute b₀.</p>
</div></div>

<h2>4. Seven Important Results</h2>
<div class="block"><div class="notes-hdr">📓 FROM NOTES</div><div class="notes">
<p>Let x₁.₂₃…ₚ = x₁ − X₁.₂₃…ₚ denote the residual. Then:</p>
</div></div>
<div class="block"><div class="formula-hdr">🔢 ALL 7 RESULTS</div><div class="formula">
<pre>1.  Mean of fitted = mean of observed:    X̄₁.₂₃…ₚ = x̄₁
2.  Mean residual = 0:                    x̄₁.₂₃…ₚ = 0
3.  Residuals uncorrelated with predictors: Cov(xᵢ, x₁.₂₃…ₚ) = 0  for i=2,…,p
4.  Fitted ⊥ residual:                    Cov(X₁.₂₃…ₚ, x₁.₂₃…ₚ) = 0
5.  Variance identity:                    V(X₁.₂₃…ₚ) = Cov(x₁, X₁.₂₃…ₚ)
6.  Variance of fitted values:            V(X₁.₂₃…ₚ) = (1 − |R|/R₁₁) · s₁²
7.  Variance of residuals:                V(x₁.₂₃…ₚ) = (|R|/R₁₁) · s₁²</pre>
</div></div>
<div class="callout"><strong>Key identity from 6+7:</strong> V(fitted) + V(residuals) = s₁² = V(x₁). Total variance is perfectly partitioned into explained + unexplained.</div>

<h2>5. Numerical Examples</h2>
<div class="block"><div class="example-hdr">✏️ EXAMPLES FROM NOTES</div><div class="example">
<pre>Iris Dataset (X₁=Sepal length, X₂=Sepal width, X₃=Petal length, X₄=Petal width):

(a) Linear:     X₁.₂₃₄ = 1.856 + 0.65084·X₂ + 0.70913·X₃ − 0.55648·X₄
                R² = 0.8586  → 85% variability explained

(b) Log-linear: X₁.₂₃₄ = 1.3263 + 2.1734·logX₂ + 1.7634·logX₃ − 0.2210·logX₄
                R² = 0.7953  → 79% variability explained

→ Linear regression is MORE efficient (R² 0.8586 > 0.7953)

Other dataset:
(a) Linear:     x̂₁.₂₃₄ = 0.410581 − 0.012621·x₂ + 0.004287·x₃ + 0.012397·x₄
                R² = 0.6911  → 69% explained
(b) Log-linear: x₁.₂₃₄ = 0.22384 − 0.11186·logx₂ + 0.05320·logx₃ + 0.03831·logx₄
                R² = 0.9063  → 90% explained

→ Log regression is MORE efficient here (R² 0.9063 > 0.6911)</pre>
</div></div>

<footer>mvnotes v1.0.0 · Run mv_correlation() for the next topic</footer>
</body></html>')
  .show_notes(html, "Multiple Regression")
}


# ============================================================
#  mv_correlation()
# ============================================================

#' Multiple & Partial Correlation Coefficients
#' @export
mv_correlation <- function() {
  html <- paste0(
'<!DOCTYPE html><html><head><meta charset="UTF-8">
<title>Correlation — mvnotes</title>', .css(), '</head><body>
<h1>Multiple Correlation Coefficient</h1>

<h2>1. Definition</h2>
<div class="block"><div class="notes-hdr">📓 FROM NOTES</div><div class="notes">
<p>The simple correlation coefficient between <strong>x₁ (observed)</strong> and <strong>X₁.₂₃…ₚ (predicted)</strong> serves as a measure of the joint statistical influence of x₂, x₃, …, xₚ on x₁.</p>
<p>Denoted <strong>R₁.₂₃…ₚ</strong> (or r₁.₂₃…ₚ) — the <em>multiple correlation coefficient</em>.</p>
</div></div>

<h2>2. Formula</h2>
<div class="block"><div class="formula-hdr">🔢 FORMULAS</div><div class="formula">
<pre>Definition:
R₁.₂₃…ₚ = Cov(x₁, X₁.₂₃…ₚ) / √[V(x₁) · V(X₁.₂₃…ₚ)]

Computational formula:
R₁.₂₃…ₚ = (1 − |R|/R₁₁)^(1/2)

Population version:
ρ²₁.₂₃…ₚ = 1 − E[V(X₁|X₂,…,Xₚ)] / V(X₁)</pre>
</div></div>

<h2>3. Remarks</h2>
<div class="block"><div class="notes-hdr">📓 FROM NOTES</div><div class="notes">
<ol>
<li>V(X₁.₂₃…ₚ) = R²₁.₂₃…ₚ · s₁²</li>
<li>V(x₁.₂₃…ₚ) = (1 − R²₁.₂₃…ₚ) · s₁²</li>
<li><strong>0 ≤ R₁.₂₃…ₚ ≤ 1</strong>  (always non-negative, unlike simple r)</li>
</ol>
</div></div>
<div class="block"><div class="explain-hdr">💡 SIMPLE EXPLANATION</div><div class="explain">
<p><strong>R² interpretation:</strong></p>
<ul>
<li>R² = 0 → predictors explain nothing about x₁</li>
<li>R² = 1 → perfect prediction</li>
<li>R² = 0.85 → "85% of variation in x₁ is explained by x₂,…,xₚ together"</li>
</ul>
<div class="callout"><strong>Unlike simple r:</strong> R ranges from 0 to 1 only (measures predictability, not direction). Simple r ranges from −1 to +1.</div>
</div></div>

<footer>mvnotes v1.0.0 · Run mv_partial_corr() for partial correlation</footer>
</body></html>')
  .show_notes(html, "Multiple Correlation")
}


# ============================================================
#  mv_partial_corr()
# ============================================================

#' Partial Correlation Coefficient and Spurious Correlation
#' @export
mv_partial_corr <- function() {
  html <- paste0(
'<!DOCTYPE html><html><head><meta charset="UTF-8">
<title>Partial Correlation — mvnotes</title>', .css(), '</head><body>
<h1>Partial Correlation Coefficient</h1>

<h2>1. Motivation</h2>
<div class="block"><div class="notes-hdr">📓 FROM NOTES</div><div class="notes">
<p>The correlation between x₁ and x₂ may be partly or wholly caused by the influence of x₃, x₄, …, xₚ on both. We want the correlation between x₁ and x₂ <strong>if the effects of x₃,…,xₚ on each of them were eliminated</strong>. This is the <em>partial correlation</em> or <em>net correlation</em>, denoted r₁₂.₃₄…ₚ.</p>
</div></div>

<h2>2. Construction via Residuals</h2>
<div class="block"><div class="notes-hdr">📓 FROM NOTES</div><div class="notes">
<p>Fit regression of x₁ on x₃,…,xₚ and of x₂ on x₃,…,xₚ:</p>
</div></div>
<div class="block"><div class="formula-hdr">🔢 FORMULA</div><div class="formula">
<pre>X₁.₃₄…ₚ = γ₀ + γ₃x₃ + γ₄x₄ + … + γₚxₚ
X₂.₃₄…ₚ = δ₀ + δ₃x₃ + δ₄x₄ + … + δₚxₚ

Residuals (parts unaffected by x₃,…,xₚ):
  x₁.₃₄…ₚ = x₁ − X₁.₃₄…ₚ
  x₂.₃₄…ₚ = x₂ − X₂.₃₄…ₚ

r₁₂.₃₄…ₚ = Corr(x₁.₃₄…ₚ, x₂.₃₄…ₚ)

Computational formula:
r₁₂.₃₄…ₚ = −R₁₂ / √(R₁₁ · R₂₂)

Range: −1 ≤ r₁₂.₃₄…ₚ ≤ 1</pre>
</div></div>

<h2>3. Spurious Correlation</h2>
<div class="block"><div class="notes-hdr">📓 FROM NOTES (Important!)</div><div class="notes">
<p>For 3 variables x₁, x₂, x₃. Suppose r₁₂.₃ = 0. Then:</p>
<pre>(r₁₂ − r₁₃r₂₃) / √[(1−r₁₃²)(1−r₂₃²)] = 0
⟹ r₁₂ = r₁₃ · r₂₃   which may ≠ 0</pre>
<p>So x₁ and x₂ have <strong>non-zero simple correlation</strong> but are <strong>uncorrelated when x₃ is accounted for</strong>. By ignoring x₃, we introduce a correlation that was not really there. This is <strong>spurious correlation</strong>.</p>
</div></div>
<div class="block"><div class="explain-hdr">💡 SIMPLE EXPLANATION</div><div class="explain">
<p><strong>Classic example:</strong> Ice cream sales (x₁) and drowning deaths (x₂) are correlated. But both are caused by hot weather (x₃). Once you control for temperature, the correlation disappears → it was spurious.</p>
<table>
<tr><th>Coefficient</th><th>What it does with x₃,…,xₚ</th></tr>
<tr><td>Simple r₁₂</td><td><em>Ignores</em> x₃,…,xₚ</td></tr>
<tr><td>Partial r₁₂.₃…ₚ</td><td><em>Takes into account and eliminates</em> the effects of x₃,…,xₚ</td></tr>
</table>
</div></div>

<h2>4. Numerical Examples from Notes</h2>
<div class="block"><div class="example-hdr">✏️ EXAMPLES</div><div class="example">
<pre>Iris Dataset:
  r₁₂ = −0.1175      (simple: slight negative)
  r₁₂.₃₄ = +0.6286   (partial: HIGH positive after removing X₃,X₄ effects)
  → X₃,X₄ were masking the true positive sepal relationship

Other Dataset:
  r₁₂ = −0.7485      Cov(x₁,x₂) = −0.748
  r₁₂.₃₄ = −0.794    (partial: slightly more negative)
  → X₃,X₄ slightly masked the negative relationship</pre>
</div></div>

<footer>mvnotes v1.0.0 · Run mv_distributions() for probability distributions</footer>
</body></html>')
  .show_notes(html, "Partial Correlation")
}


# ============================================================
#  mv_distributions()
# ============================================================

#' Multivariate Probability Distributions, Mean Vector & Dispersion Matrix
#' @export
mv_distributions <- function() {
  html <- paste0(
'<!DOCTYPE html><html><head><meta charset="UTF-8">
<title>Distributions — mvnotes</title>', .css(), '</head><body>
<h1>Multivariate Probability Distributions</h1>

<h2>1. Joint Distributions</h2>
<div class="block"><div class="formula-hdr">🔢 FORMULAS</div><div class="formula">
<pre>Discrete: f(x₁,…,xₚ) ≥ 0,   Σ f(x₁,…,xₚ) = 1

Continuous: f(x₁,…,xₚ) ≥ 0,  ∫⋯∫ f dx₁…dxₚ = 1

Marginal of Xᵢ:        g(xᵢ) = Σ f(x₁,…,xₚ)     [sum over all other variables]
Marginal of X₁,…,Xq:   g(x₁,…,xq) = Σ f(x₁,…,xₚ) [sum over xq₊₁,…,xₚ]
Conditional X₁|x₂,…,xₚ: f(x₁|x₂,…,xₚ) = f(x₁,…,xₚ) / g(x₂,…,xₚ)

Joint CDF: F(x₁,…,xₚ) = P(X₁≤x₁, X₂≤x₂, …, Xₚ≤xₚ)</pre>
</div></div>

<h2>2. Mean Vector & Dispersion Matrix</h2>
<div class="block"><div class="notes-hdr">📓 FROM NOTES</div><div class="notes">
<p>E(Xᵢ)=μᵢ, V(Xᵢ)=σᵢ², Cov(Xᵢ,Xⱼ)=ρᵢⱼσᵢσⱼ, |ρᵢⱼ|≤1</p>
</div></div>
<div class="block"><div class="formula-hdr">🔢 FORMULAS</div><div class="formula">
<pre>Mean Vector:  μ = E(X) = (μ₁, μ₂, …, μₚ)ʼ

Dispersion Matrix:
Σ = E[(X−μ)(X−μ)ʼ]

  ⎡ σ₁²   σ₁₂  σ₁₃ … σ₁ₚ ⎤
= ⎢ σ₂₁   σ₂²  σ₂₃ … σ₂ₚ ⎥   where σᵢⱼ = Cov(Xᵢ,Xⱼ)
  ⎣ σₚ₁   σₚ₂  σₚ₃ …  σₚ²⎦

Properties: Σ is symmetric, positive definite.
Also called Variance-Covariance Matrix.

Correlation Matrix R: replace σᵢⱼ with ρᵢⱼ = σᵢⱼ/(σᵢσⱼ), diagonal = 1.

Key Results:
  For any real vector a:   E(aʼX)=aʼμ,  V(aʼX)=aʼΣa
  For any real matrix C:   E(CX)=Cμ,    D(CX)=CΣCʼ</pre>
</div></div>
<div class="block"><div class="explain-hdr">💡 SIMPLE EXPLANATION</div><div class="explain">
<p><strong>Mean vector</strong>: stack all means in a column vector. <strong>Dispersion matrix Σ</strong>: diagonal = variances, off-diagonal = covariances. <strong>Correlation matrix R</strong>: standardised Σ (diagonal = 1, off-diagonal = ρᵢⱼ).</p>
<div class="callout"><strong>Transformation rules:</strong> Any linear combination or linear transformation of X inherits its distribution properties directly via aʼμ and aʼΣa (or CΣCʼ).</div>
</div></div>

<footer>mvnotes v1.0.0 · Run mv_normal() for the MVN distribution</footer>
</body></html>')
  .show_notes(html, "Multivariate Distributions")
}


# ============================================================
#  mv_normal()
# ============================================================

#' Multivariate Normal Distribution
#' @export
mv_normal <- function() {
  html <- paste0(
'<!DOCTYPE html><html><head><meta charset="UTF-8">
<title>MVN — mvnotes</title>', .css(), '</head><body>
<h1>Multivariate Normal Distribution (MVN)</h1>

<h2>1. Density Function</h2>
<div class="block"><div class="formula-hdr">🔢 FORMULAS</div><div class="formula">
<pre>Univariate: f(x) = 1/(σ√2π) · exp[−(x−μ)²/(2σ²)]

p-Variate MVN:
f(x) = 1/((2π)^(p/2)|Σ|^(1/2)) · exp[−½(x−μ)ʼΣ⁻¹(x−μ)]

Notation: X ~ Nₚ(μ, Σ)

BVN (p=2):
f(x₁,x₂) = 1/(2π√σ₁₁√σ₂₂√(1−ρ₁₂²))
  · exp{−1/(2(1−ρ₁₂²)) [(x₁−μ₁)²/σ₁₁ + (x₂−μ₂)²/σ₂₂
                          − 2ρ₁₂(x₁−μ₁)(x₂−μ₂)/(√σ₁₁√σ₂₂)]}

Special: ρ₁₂=0 ⟹ f(x₁,x₂) = f(x₁)·f(x₂) ⟹ X₁ ⊥ X₂
In MVN:  UNCORRELATED  ⟺  INDEPENDENT</pre>
</div></div>

<h2>2. Result 1 — Linear Combinations</h2>
<div class="block"><div class="formula-hdr">🔢 RESULT</div><div class="formula">
<pre>If X ~ Nₚ(μ, Σ) and A is m×p with rank m ≤ p:
  Y = AX  ~  Nₘ(Aμ, AΣAʼ)

Special case (m=1):
  aʼX  ~  N(aʼμ, aʼΣa)   [univariate normal]

Any subset of elements of X is also MVN.
CAUTION: Normal marginals do NOT necessarily imply joint normality.</pre>
</div></div>

<h2>3. Result 2 — Partitioning & Conditional Distributions</h2>
<div class="block"><div class="formula-hdr">🔢 RESULT</div><div class="formula">
<pre>Partition: X = (X⁽¹⁾ : q×1 ,  X⁽²⁾ : (p−q)×1)ʼ
           μ = (μ⁽¹⁾, μ⁽²⁾)ʼ
           Σ = |Σ₁₁  Σ₁₂|
               |Σ₂₁  Σ₂₂|

Independence: X⁽¹⁾ ⊥ X⁽²⁾  ⟺  Σ₁₂ = 0

Conditional Distributions:
X⁽²⁾ | X⁽¹⁾=x⁽¹⁾  ~  N_{p−q}(μ⁽²⁾ + Σ₂₁Σ₁₁⁻¹(x⁽¹⁾−μ⁽¹⁾),  Σ₂₂.₁)
  where  Σ₂₂.₁ = Σ₂₂ − Σ₂₁Σ₁₁⁻¹Σ₁₂

X⁽¹⁾ | X⁽²⁾=x⁽²⁾  ~  N_q(μ⁽¹⁾ + Σ₁₂Σ₂₂⁻¹(x⁽²⁾−μ⁽²⁾),  Σ₁₁.₂)
  where  Σ₁₁.₂ = Σ₁₁ − Σ₁₂Σ₂₂⁻¹Σ₂₁</pre>
</div></div>
<div class="block"><div class="explain-hdr">💡 KEY POINTS</div><div class="explain">
<p><strong>Conditional mean</strong>: original mean + regression correction term.<br>
<strong>Conditional variance</strong>: always smaller than unconditional — knowing more reduces uncertainty.<br>
<strong>Σ₂₂.₁</strong> is called the Schur complement of Σ₁₁.</p>
</div></div>

<footer>mvnotes v1.0.0 · Run mv_multinomial() for multinomial distribution</footer>
</body></html>')
  .show_notes(html, "Multivariate Normal")
}


# ============================================================
#  mv_multinomial()
# ============================================================

#' Multinomial Distribution and All 7 Properties
#' @export
mv_multinomial <- function() {
  html <- paste0(
'<!DOCTYPE html><html><head><meta charset="UTF-8">
<title>Multinomial — mvnotes</title>', .css(), '</head><body>
<h1>Multinomial Distribution</h1>

<h2>1. Joint PMF</h2>
<div class="block"><div class="formula-hdr">🔢 FORMULA</div><div class="formula">
<pre>(X₁,X₂,…,Xk) ~ Multinomial(n; p₁,p₂,…,pk)

f(x₁,…,xk) = n! / (x₁!x₂!⋯xk!(n−Σxᵢ)!) · p₁^x₁ p₂^x₂ ⋯ pk^xk · (1−Σpᵢ)^(n−Σxᵢ)

where xᵢ = 0,1,…,n ∀i,   Σxᵢ ≤ n,   0 < pᵢ < 1,   Σpᵢ < 1

NOTE: Avoid the (k+1)-variable form with Σpᵢ=1, Σxᵢ=n
      → dispersion matrix becomes SINGULAR</pre>
</div></div>

<h2>2. The 7 Properties ★ Exam Important</h2>
<div class="block"><div class="formula-hdr">🔢 ALL PROPERTIES</div><div class="formula">
<pre>P1: Marginal of Xᵢ ~ Binomial(n, pᵢ)

P2: Marginal of (X₁,…,Xq) for q&lt;k ~ Multinomial(n, p₁,…,pq)

P3: Conditional of X₁ | X₂=x₂,…,Xk=xk ~ Binomial(n−Σᵢ₌₂ᵏxᵢ, p₁*)
    where p₁* = p₁ / (1 − Σᵢ₌₂ᵏ pᵢ)

P4: Conditional of (X₁,…,Xq) | Xq₊₁=xq₊₁,…,Xk=xk
    ~ Multinomial(n−Σᵢ₌q₊₁ᵏxᵢ, p₁*,…,pq*)
    where pⱼ* = pⱼ / (1 − Σᵢ₌q₊₁ᵏ pᵢ),  j=1,…,q

P5: S = X₁+X₂+⋯+Xq (q≤k) ~ Binomial(n, Σᵢ₌₁q pᵢ)

P6: Cov(Xᵢ, Xⱼ) = −npᵢpⱼ   for i≠j   (always negative)

P7★: True regression of X₁ on X₂,…,Xk is LINEAR:
     E(X₁|x₂,…,xk) = (n−x₂−⋯−xk) · p₁*  ← linear in x₂,…,xk</pre>
</div></div>

<h2>3. Multiple & Partial Correlation</h2>
<div class="block"><div class="formula-hdr">🔢 FORMULAS</div><div class="formula">
<pre>Multiple Correlation:
  ρ²₁.₂₃…k = (p₁* − p₁)/(1 − p₁)
  ρ₁.₂₃…k  = √[(p₁* − p₁)/(1 − p₁)]

Partial Correlation:
  ρ₁₂.₃₄…k = −√(p₁p₂) / [√(1−p₁−p₃−⋯−pk) · √(1−p₂−p₃−⋯−pk)]
             = −n·p₁·p₂* / √[n·p₁(1−p₁*)·n·p₂(1−p₂*)]</pre>
</div></div>

<footer>mvnotes v1.0.0 · Run mv_wishart() for Wishart & Hotelling T²</footer>
</body></html>')
  .show_notes(html, "Multinomial Distribution")
}


# ============================================================
#  mv_wishart()
# ============================================================

#' Wishart Distribution and Hotelling T2
#' @export
mv_wishart <- function() {
  html <- paste0(
'<!DOCTYPE html><html><head><meta charset="UTF-8">
<title>Wishart & T2 — mvnotes</title>', .css(), '</head><body>
<h1>Wishart Distribution & Hotelling T²</h1>

<h2>1. Sampling from MVN</h2>
<div class="block"><div class="formula-hdr">🔢 FORMULAS</div><div class="formula">
<pre>Sample of n obs from X ~ Nₚ(μ,Σ): x₁,x₂,…,xₙ (n>p)
  xα = (xα₁, xα₂, …, xαₚ)ʼ  (α=1,…,n)

Sample Mean Vector:    x̄ = (1/n)Σα xα = (x̄₁,…,x̄ₚ)ʼ

SSCP Matrix:           A = Σα (xα−x̄)(xα−x̄)ʼ

MLE:  μ̂ = x̄ (unbiased)
      Σ̂ = A/n  (BIASED — divides by n not n−1)

Theorem: x̄ ~ Nₚ(μ, Σ/n),  independent of Σ̂</pre>
</div></div>

<h2>2. Wishart Distribution</h2>
<div class="block"><div class="formula-hdr">🔢 FORMULAS</div><div class="formula">
<pre>If M = XʼX where X_{n×p} is from Nₚ(0,Σ):
  M ~ Wₚ(Σ, m)   [Wishart with d.f. m]

Special cases:
  Σ=I  → standard Wishart
  p=1, Σ=1 → M = Σxᵢ² ~ χ²_m

Properties:
  1. Sum of independent W(Σ,m₁)+⋯+W(Σ,mk) ~ Wₚ(Σ, Σmᵢ)
  2. E(M) = mΣ
  3. M~Wₚ(Σ,m), B p×q matrix → BʼMB ~ Wq(BʼΣB, m)
  4. A = nΣ̂ ~ Wₚ(Σ, n−1)

Analogy: Univariate (n−1)s² ~ σ²χ²_{n-1}
         Multivariate A ~ Wₚ(Σ, n−1)</pre>
</div></div>

<h2>3. Hotelling T²</h2>
<div class="block"><div class="formula-hdr">🔢 FORMULAS</div><div class="formula">
<pre>Z = m · dʼ M⁻¹ d
  where d ~ Nₚ(0,Iₚ),  M ~ Wₚ(I,m),  d ⊥ M

Z ~ T²(p,m)   [Hotelling T²]

Relationship with F:
  T²(p,m) = [mp/(m−p+1)] · F_{p, m−p+1}

Multivariate one-sample test statistic:
  T² = n(x̄−μ₀)ʼ S⁻¹ (x̄−μ₀)

When p=1: T²(1,m) = F(1,m) = t²(m)  ← reduces to ordinary t-test</pre>
</div></div>
<div class="callout"><strong>Hotelling T² = multivariate t-test.</strong> Use T² to test H₀: μ=μ₀ (is the mean vector equal to a specified value?). Convert to F using the formula to get the p-value.</div>

<footer>mvnotes v1.0.0 · Run mv_visualization() for visualization techniques</footer>
</body></html>')
  .show_notes(html, "Wishart & Hotelling T2")
}


# ============================================================
#  mv_visualization()
# ============================================================

#' Multivariate Visualization Techniques
#' @export
mv_visualization <- function() {
  html <- paste0(
'<!DOCTYPE html><html><head><meta charset="UTF-8">
<title>Visualization — mvnotes</title>', .css(), '</head><body>
<h1>Multivariate Visualization Techniques</h1>
<table>
<tr><th>Technique</th><th>Data</th><th>Best For</th></tr>
<tr><td>Mosaic Plot</td><td>Categorical</td><td>Contingency tables, Pearson residuals</td></tr>
<tr><td>SPLOM/Pair Plot</td><td>Continuous</td><td>All pairwise correlations at once</td></tr>
<tr><td>Q-Q Plot</td><td>Continuous</td><td>Normality, comparing distributions</td></tr>
<tr><td>Spider/Radar</td><td>Quantitative</td><td>Multi-dimensional profiles</td></tr>
<tr><td>DD Plot</td><td>Any multivariate</td><td>Nonparametric comparison of 2 datasets</td></tr>
<tr><td>Parallel Coordinates</td><td>Multivariate</td><td>High-dimensional patterns, clusters</td></tr>
<tr><td>Trellis Display</td><td>Any</td><td>Same chart across many subgroups</td></tr>
</table>

<h2>1. Mosaic Plot</h2>
<div class="block"><div class="notes-hdr">📓 FROM NOTES</div><div class="notes">
<p>Area of each rectangle = proportional to frequency of that category combination. Used to detect associations between categorical variables.</p>
<ul>
<li><strong>Column width</strong>: proportional to marginal frequency of first variable</li>
<li><strong>Block height</strong>: proportional to conditional frequency within each column</li>
<li><strong>Blue</strong>: positive Pearson residual (more than expected)</li>
<li><strong>Red</strong>: negative Pearson residual (less than expected)</li>
</ul>
</div></div>
<div class="block"><div class="formula-hdr">🔢 PEARSON RESIDUAL</div><div class="formula">
<pre>Pearson Residual = (Observed − Expected) / √Expected
Expected = (Row Total × Column Total) / Grand Total

Example (n=100):
           Young  Old  Total        Expected:    Young  Old
Treatment    30   20    50          Treatment:    20    30
Placebo      10   40    50          Placebo:      20    30
Total        40   60   100

Residuals:
  (Treat, Young): (30−20)/√20 = +2.24  ← more young on treatment than expected
  (Treat, Old):   (20−30)/√30 = −1.83
  (Plac,  Young): (10−20)/√20 = −2.24
  (Plac,  Old):   (40−30)/√30 = +1.83

χ² = 2.24² + 1.83² + 2.24² + 1.83² = 16.73</pre>
</div></div>

<h2>2. Scatterplot Matrix (SPLOM / Pair Plot)</h2>
<div class="block"><div class="notes-hdr">📓 FROM NOTES</div><div class="notes">
<p>A p×p grid of scatterplots showing all pairwise relationships. Diagonal shows each variable\'s distribution. Reveals correlations, clusters, outliers, and non-linearity.</p>
<ul>
<li>Tight upward band → positive correlation</li>
<li>Tight downward band → negative correlation</li>
<li>Circular cloud → near-zero correlation</li>
<li>Isolated point → outlier</li>
</ul>
<p>With p variables: p(p−1)/2 unique plots. For p=4: 6 plots; p=10: 45 plots.</p>
</div></div>

<h2>3. Bivariate Q-Q Plot</h2>
<div class="block"><div class="notes-hdr">📓 FROM NOTES</div><div class="notes">
<p>Compares quantiles of two distributions. Points on diagonal y=x → same distribution. Uses: normality checks, outlier detection, model validation, comparing two datasets.</p>
<ul>
<li>Points on diagonal → same distribution</li>
<li>Curve at ends → heavier tails (leptokurtic)</li>
<li>S-shape → skewness difference</li>
<li>Points off the line → outliers</li>
</ul>
</div></div>

<h2>4. Spider / Radar Chart</h2>
<div class="block"><div class="notes-hdr">📓 FROM NOTES</div><div class="notes">
<p>Displays data across several dimensions using <strong>polar coordinates</strong>. Each dimension has its own axis radiating from the centre. Values are connected to form a polygon.</p>
<p>Best for comparing profiles (e.g., athletes across skills). Avoid for >8 dimensions or when precise comparisons are needed.</p>
</div></div>

<h2>5. DD Plot (Depth vs Depth)</h2>
<div class="block"><div class="notes-hdr">📓 FROM NOTES</div><div class="notes">
<p>Nonparametric comparison of two multivariate datasets. For each point, compute its depth in distribution F and in distribution G. Plot (depth_F, depth_G) pairs.</p>
<ul>
<li>Points on diagonal y=x → same distribution (F=G)</li>
<li>Leaf shape deviating from diagonal → location shift</li>
<li>Other deviations → scale or skewness differences</li>
</ul>
<p>Applications: Graphical comparison, hypothesis testing (permutation tests), outlier detection, DD-classifier for nonparametric classification.</p>
</div></div>

<h2>6. Parallel Coordinate Plot</h2>
<div class="block"><div class="notes-hdr">📓 FROM NOTES</div><div class="notes">
<p>Each variable = one vertical axis. Each observation = one polyline crossing all axes. Position of line on each axis = value of that variable.</p>
<ul>
<li>Parallel lines between two axes → positive correlation</li>
<li>Lines forming X between two axes → negative correlation</li>
<li>Distinct bands → clusters</li>
<li>Lines that diverge from the flow → outliers</li>
</ul>
</div></div>

<h2>7. Trellis Display</h2>
<div class="block"><div class="notes-hdr">📓 FROM NOTES</div><div class="notes">
<p>A grid of identical small charts, each for a different subgroup of the data. Allows comparison of patterns across many subgroups simultaneously. Each panel has the same scale for fair comparison.</p>
<p>Modern equivalents: <code>facet_wrap()</code> / <code>facet_grid()</code> in ggplot2; subplots in Plotly.</p>
</div></div>

<footer>mvnotes v1.0.0 · Run mv_problems() for worked problem sets</footer>
</body></html>')
  .show_notes(html, "Visualization Techniques")
}


# ============================================================
#  mv_problems()
# ============================================================

#' Worked Problem Sets
#' @export
mv_problems <- function() {
  html <- paste0(
'<!DOCTYPE html><html><head><meta charset="UTF-8">
<title>Problems — mvnotes</title>', .css(), '</head><body>
<h1>Worked Problem Sets</h1>

<h2>Problem Set 2 — Multinomial Distribution</h2>

<h3>Q1. Balls in Cells</h3>
<div class="block"><div class="example-hdr">✏️ PROBLEM</div><div class="example">
<p>10 distinguishable balls distributed at random over 4 cells (each cell can receive any number). Xᵢ = number of balls in cell i. Find: (i) P{X₁=1,X₂=2,X₃=3,X₄=4}, (ii) E & V of X₁ given X₂=2,X₃=3, (iii) partial correlation r₁₂.₃₄.</p>
</div></div>
<div class="block"><div class="solution-hdr">✅ SOLUTION</div><div class="solution">
<pre>Setup: p₁=p₂=p₃=p₄=1/4, n=10.
(X₁,X₂,X₃,X₄) ~ Multinomial(10; 1/4,1/4,1/4,1/4)

(i) P{X₁=1,X₂=2,X₃=3,X₄=4}:
  = 10!/(1!·2!·3!·4!) · (1/4)^10
  = 3628800/288 · 1/1048576
  = 12600/1048576 ≈ 0.01202

(ii) Given X₂=2, X₃=3: 5 balls used, n−x₂−x₃ = 10−2−3 = 5 remain.
  By P3: X₁|X₂=2,X₃=3 ~ Binomial(5, p₁*)
  p₁* = p₁/(1−p₂−p₃) = (1/4)/(1/2) = 1/2
  E(X₁|X₂=2,X₃=3) = 5·(1/2) = 2.5
  V(X₁|X₂=2,X₃=3) = 5·(1/2)·(1/2) = 1.25

(iii) Partial correlation r₁₂.₃₄:
  ρ₁₂.₃₄ = −√(p₁p₂) / [√(1−p₁−p₃−p₄)·√(1−p₂−p₃−p₄)]
          = −√(1/16) / [√(1/4)·√(1/4)]
          = −(1/4) / (1/4) = −1</pre>
</div></div>

<h3>Q2. Loaded Die</h3>
<div class="block"><div class="example-hdr">✏️ PROBLEM</div><div class="example">
<p>Die probabilities: p₁=0.10, p₂=0.30, p₃=0.25, p₄=0.20, p₅=0.09, p₆=0.06. Thrown 20 times. fᵢ = count of face i. Find: (a) Corr(f₂,f₅) and partial corr r₂₅.₁₃₄₆, (b) V(f₂|f₁=3,f₃=3,f₄=3,f₅=3).</p>
</div></div>
<div class="block"><div class="solution-hdr">✅ SOLUTION</div><div class="solution">
<pre>Setup: (f₁,…,f₆) ~ Multinomial(20; 0.10,0.30,0.25,0.20,0.09,0.06)

(a) Corr(f₂,f₅):
  Cov(f₂,f₅) = −n·p₂·p₅ = −20·0.30·0.09 = −0.54
  V(f₂) = 20·0.30·0.70 = 4.2
  V(f₅) = 20·0.09·0.91 = 1.638
  r₂₅ = −0.54/√(4.2·1.638) = −0.54/2.623 ≈ −0.206

  Partial r₂₅ eliminating f₁,f₃ (keep f₄,f₆ too):
  ρ₂₅.₁₃₄₆ = −√(p₂p₅)/[√(1−p₂−p₁−p₃)·√(1−p₅−p₁−p₃)]
  = −√(0.027)/[√(0.35)·√(0.56)]
  = −0.1643/[0.5916·0.7483] = −0.1643/0.4427 ≈ −0.371

(b) V(f₂|f₁=3,f₃=3,f₄=3,f₅=3):
  Fixed balls = 3+3+3+3 = 12.  Remaining = 20−12 = 8.
  p₂* = p₂/(1−p₁−p₃−p₄−p₅) = 0.30/(0.36) = 0.8333
  f₂|given ~ Binomial(8, 0.8333)
  V(f₂|given) = 8·0.8333·0.1667 ≈ 1.111</pre>
</div></div>

<h3>Q3. Word Classification</h3>
<div class="block"><div class="example-hdr">✏️ PROBLEM</div><div class="example">
<p>10 words: positive (p=0.4), neutral (p=0.3), negative (p=0.3). Find: (a) P(4 pos,3 neu,3 neg), (b) E & V of positive count, (c) Cov(positive, neutral).</p>
</div></div>
<div class="block"><div class="solution-hdr">✅ SOLUTION</div><div class="solution">
<pre>Setup: (X,Y,Z) ~ Trinomial(10; 0.4, 0.3, 0.3)

(a) P(X=4,Y=3,Z=3):
  = 10!/(4!·3!·3!) · (0.4)⁴·(0.3)³·(0.3)³
  = 4200 · 0.0256 · 0.027 · 0.027
  = 4200 · 0.00001866 ≈ 0.0784

(b) By P1: X ~ Binomial(10, 0.4)
  E(X) = 10·0.4 = 4
  V(X) = 10·0.4·0.6 = 2.4

(c) By P6: Cov(X,Y) = −n·p_X·p_Y = −10·0.4·0.3 = −1.2
  (Negative: more positive words → fewer neutral, since total = 10)</pre>
</div></div>

<h2>Problem Set 1 — Method Guide (Chicken Data)</h2>
<div class="block"><div class="example-hdr">✏️ PROBLEM (Multivariate_1.docx)</div><div class="example">
<p>Variables: x₁=per capita chicken demand, x₂=chicken price, x₃=fish price, x₄=per capita income across Indian states. Tasks: (a) fit linear regression x₁~x₂,x₃,x₄; (b) fit log-linear x₁~lnx₂,lnx₃,lnx₄; (c) compare R²; (d) compute r₁₂; (e) compute r₁₂.₃₄; (f) comment.</p>
</div></div>
<div class="block"><div class="solution-hdr">✅ METHOD</div><div class="solution">
<pre>Steps for (a) and (b):
  1. Compute x̄ᵢ and sᵢ for each variable
  2. Build 4×4 correlation matrix R
  3. Compute cofactors R₁₁, R₁₂, R₁₃, R₁₄
  4. bⱼ = −(R₁ⱼ/R₁₁)·(s₁/sⱼ);  b₀ = x̄₁−b₂x̄₂−b₃x̄₃−b₄x̄₄
  5. R² = 1 − |R|/R₁₁  (measure of efficacy)
  For (b): replace x₂,x₃,x₄ with lnx₂,lnx₃,lnx₄ throughout.

For (d): r₁₂ = s₁₂/(s₁s₂)

For (e): r₁₂.₃₄ = −R₁₂/√(R₁₁·R₂₂)

For (f): If r₁₂ ≠ r₁₂.₃₄ significantly:
  → x₃ and/or x₄ are confounders of the x₁–x₂ relationship
  → If r₁₂ ≈ 0 but r₁₂.₃₄ ≠ 0: controlling for income/fish price REVEALS a relationship
  → If r₁₂ ≠ 0 but r₁₂.₃₄ ≈ 0: the simple correlation is SPURIOUS</pre>
</div></div>

<footer>mvnotes v1.0.0 · Run mv_formulas() for the formula quick-reference sheet</footer>
</body></html>')
  .show_notes(html, "Problem Sets")
}


# ============================================================
#  mv_formulas()
# ============================================================

#' Quick Reference Formula Sheet
#' @export
mv_formulas <- function() {
  html <- paste0(
'<!DOCTYPE html><html><head><meta charset="UTF-8">
<title>Formula Sheet — mvnotes</title>', .css(), '</head><body>
<h1>Quick Reference — All Formulas</h1>

<h2>Descriptive Statistics</h2>
<div class="block"><div class="formula-hdr">🔢 FORMULAS</div><div class="formula">
<pre>x̄ᵢ = (1/n)Σα xᵢα           sᵢ² = (1/n)Σα(xᵢα−x̄ᵢ)²
sᵢⱼ = (1/n)Σα(xᵢα−x̄ᵢ)(xⱼα−x̄ⱼ)    rᵢⱼ = sᵢⱼ/(sᵢsⱼ)

bⱼ = −(R₁ⱼ/R₁₁)·(s₁/sⱼ)          b₀ = x̄₁ − b₂x̄₂ − ⋯ − bₚx̄ₚ
V(fitted)   = (1 − |R|/R₁₁)·s₁²   V(residuals) = (|R|/R₁₁)·s₁²
R₁.₂₃…ₚ    = (1 − |R|/R₁₁)^(1/2)
r₁₂.₃₄…ₚ   = −R₁₂/√(R₁₁·R₂₂)</pre>
</div></div>

<h2>Probability Distributions</h2>
<div class="block"><div class="formula-hdr">🔢 FORMULAS</div><div class="formula">
<pre>Marginal:   g(xᵢ) = Σ f(x₁,…,xₚ)
Conditional: f(x₁|x₂,…,xₚ) = f(x₁,…,xₚ)/g(x₂,…,xₚ)

Mean vector:  μ = E(X) = (μ₁,…,μₚ)ʼ
Dispersion:   Σ = E[(X−μ)(X−μ)ʼ]      (diagonal=variances, off-diag=covariances)
Linear transform: E(aʼX)=aʼμ, V(aʼX)=aʼΣa;  E(CX)=Cμ, D(CX)=CΣCʼ</pre>
</div></div>

<h2>Multinomial</h2>
<div class="block"><div class="formula-hdr">🔢 FORMULAS</div><div class="formula">
<pre>f(x₁,…,xk) = n!/(x₁!⋯xk!(n−Σxᵢ)!) · p₁^x₁⋯pk^xk·(1−Σpᵢ)^(n−Σxᵢ)

P1: Xᵢ ~ Bin(n,pᵢ)           P5: Σⱼ₌₁q Xⱼ ~ Bin(n, Σⱼ₌₁q pⱼ)
P3: X₁|others ~ Bin(n−Σxᵢ, p₁*)    p₁* = p₁/(1−Σpᵢ for i≥2)
P6: Cov(Xᵢ,Xⱼ) = −npᵢpⱼ     P7★: E(X₁|x₂,…,xk) is LINEAR

Multiple corr:  ρ₁.₂₃…k = √[(p₁*−p₁)/(1−p₁)]
Partial corr:   ρ₁₂.₃₄…k = −√(p₁p₂)/[√(1−p₁−rest)·√(1−p₂−rest)]</pre>
</div></div>

<h2>Multivariate Normal</h2>
<div class="block"><div class="formula-hdr">🔢 FORMULAS</div><div class="formula">
<pre>X ~ Nₚ(μ,Σ):  f(x) ∝ |Σ|^(-1/2)·exp[−½(x−μ)ʼΣ⁻¹(x−μ)]
AX ~ Nₘ(Aμ, AΣAʼ)
Cond. mean:   μ⁽²⁾ + Σ₂₁Σ₁₁⁻¹(x⁽¹⁾−μ⁽¹⁾)
Cond. var:    Σ₂₂.₁ = Σ₂₂ − Σ₂₁Σ₁₁⁻¹Σ₁₂
Independence: X⁽¹⁾⊥X⁽²⁾  ⟺  Σ₁₂=0   (in MVN: uncorr ⟺ indep)</pre>
</div></div>

<h2>Wishart & Hotelling T²</h2>
<div class="block"><div class="formula-hdr">🔢 FORMULAS</div><div class="formula">
<pre>MLE: μ̂=x̄, Σ̂=A/n (biased);  A ~ Wₚ(Σ, n−1)
E(M)=mΣ;  BʼMB ~ Wq(BʼΣB, m)
T²(p,m) = [mp/(m−p+1)]·F_{p,m−p+1}</pre>
</div></div>

<h2>Pearson Residual</h2>
<div class="block"><div class="formula-hdr">🔢 FORMULAS</div><div class="formula">
<pre>Pearson Residual = (Observed − Expected)/√Expected
Expected = (Row Total × Col Total)/Grand Total
χ² = Σ (Pearson Residuals)²</pre>
</div></div>

<footer>mvnotes v1.0.0 · Type mvnotes() to return to the index</footer>
</body></html>')
  .show_notes(html, "Formula Quick Reference")
}
